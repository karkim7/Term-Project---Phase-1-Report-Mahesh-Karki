const express = require('express');
const mysql = require('mysql2');
const bodyParser = require('body-parser');
const cors = require('cors');
const app = express();

// Middleware - MUST come before routes
app.use(cors());
app.use(bodyParser.json());       // For JSON data
app.use(bodyParser.urlencoded({ extended: true }));  // For form data

// MySQL Connection
const db = mysql.createConnection({
  host: 'student-registration-db.cy5e4eiyes88.us-east-1.rds.amazonaws.com',
  user: 'admin',
  password: 'admin159357',
  database: 'student_db'
});

// Test DB connection
db.connect((err) => {
  if (err) throw err;
  console.log('Connected to MySQL!');
});

// Handle form submission
app.post('/register', (req, res) => {
  const { name, email, age } = req.body;
  console.log('Received data:', { name, email, age }); // Debug log
  
  const sql = 'INSERT INTO registrations (name, email, age) VALUES (?, ?, ?)';
  db.query(sql, [name, email, age], (err) => {
    if (err) {
      console.error('Database error:', err);
      return res.status(500).send('Database error');
    }
    res.send('Registration successful!');
  });
});

// Start server
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`Server running on http://localhost:${PORT}`);
});